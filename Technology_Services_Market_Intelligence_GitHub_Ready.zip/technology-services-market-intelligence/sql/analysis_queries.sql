-- PostgreSQL examples.
-- Import data/provider_benchmark.csv into a table named provider_benchmark.
-- All included values are synthetic examples; replace with cited real data before drawing market conclusions.

-- 1. Latest reported revenue per provider in the sample
WITH ranked AS (
    SELECT *,
           ROW_NUMBER() OVER (PARTITION BY provider ORDER BY fiscal_year DESC) AS rn
    FROM provider_benchmark
)
SELECT provider, fiscal_year, revenue_usd_bn, genai_focus
FROM ranked
WHERE rn = 1
ORDER BY revenue_usd_bn DESC;

-- 2. Year-over-year revenue growth
SELECT
    provider,
    fiscal_year,
    revenue_usd_bn,
    ROUND(
        100.0 * (revenue_usd_bn - LAG(revenue_usd_bn) OVER (
            PARTITION BY provider ORDER BY fiscal_year
        )) / NULLIF(LAG(revenue_usd_bn) OVER (
            PARTITION BY provider ORDER BY fiscal_year
        ), 0),
        2
    ) AS revenue_growth_pct
FROM provider_benchmark
ORDER BY provider, fiscal_year;

-- 3. Providers with a GenAI focus by year
SELECT fiscal_year, genai_focus, COUNT(DISTINCT provider) AS provider_count
FROM provider_benchmark
GROUP BY fiscal_year, genai_focus
ORDER BY fiscal_year, genai_focus;

-- 4. Service portfolio coverage (simple substring matching for this starter dataset)
SELECT
    fiscal_year,
    COUNT(DISTINCT provider) AS provider_count,
    COUNT(DISTINCT CASE WHEN service_portfolio ILIKE '%Cloud%' THEN provider END) AS cloud_providers,
    COUNT(DISTINCT CASE WHEN service_portfolio ILIKE '%Cybersecurity%' THEN provider END) AS cybersecurity_providers,
    COUNT(DISTINCT CASE WHEN service_portfolio ILIKE '%Data & AI%' THEN provider END) AS data_ai_providers
FROM provider_benchmark
GROUP BY fiscal_year
ORDER BY fiscal_year;

-- 5. Geographic presence (simple substring matching for this starter dataset)
SELECT
    fiscal_year,
    COUNT(DISTINCT CASE WHEN geographic_presence ILIKE '%North America%' THEN provider END) AS north_america,
    COUNT(DISTINCT CASE WHEN geographic_presence ILIKE '%Europe%' THEN provider END) AS europe,
    COUNT(DISTINCT CASE WHEN geographic_presence ILIKE '%Asia-Pacific%' THEN provider END) AS asia_pacific
FROM provider_benchmark
GROUP BY fiscal_year
ORDER BY fiscal_year;
