# Power BI Dashboard Build Guide

> The current data is synthetic and is suitable for practicing dashboard mechanics only.

## 1. Import data
1. Open Power BI Desktop.
2. Select **Home → Get data → Text/CSV**.
3. Choose `data/provider_benchmark.csv` and load it.
4. In Power Query, confirm `fiscal_year` is a whole number and `revenue_usd_bn` is a decimal number.
5. Rename the table `ProviderBenchmark`.

## 2. Suggested one-page layout
- Top row: Provider Count, Average Revenue, GenAI Focus Providers.
- Main left: bar chart of provider and latest-year revenue.
- Main right: line chart with fiscal year on the X-axis, revenue on Y-axis, provider as legend.
- Bottom: table of provider, service portfolio, geography, strategic focus and GenAI focus.
- Slicers: fiscal year, provider, and GenAI focus.

## 3. Starter DAX measures

```DAX
Provider Count = DISTINCTCOUNT(ProviderBenchmark[provider])

Average Revenue = AVERAGE(ProviderBenchmark[revenue_usd_bn])

GenAI Focus Providers =
CALCULATE(
    DISTINCTCOUNT(ProviderBenchmark[provider]),
    ProviderBenchmark[genai_focus] = "Yes"
)
```

These measures are basic examples. Because each provider has multiple years, the GenAI measure responds to report filters and should be interpreted in that context. For a proper latest-year KPI, create a dedicated latest-year table/measure and test it with slicers.

## 4. Dashboard quality checklist
- Add a title and reporting period.
- Show units (illustrative USD billions) on revenue visuals.
- Display a visible note: `Synthetic demonstration data — not actual company results`.
- Include a source table/page when using real data.
- Avoid implying total company revenue equals technology-services revenue unless definitions match.
- Check filters and totals before sharing.
