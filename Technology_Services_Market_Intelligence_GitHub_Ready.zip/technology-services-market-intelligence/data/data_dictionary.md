# Data Dictionary

The included `provider_benchmark.csv` is a **synthetic practice dataset**. Provider names and values are fictional and must not be described as real market findings.

| Column | Meaning | Format / guidance |
|---|---|---|
| `provider` | Fictional technology-services provider label | Text; one of five illustrative providers |
| `fiscal_year` | Fiscal year represented by the row | Whole number |
| `revenue_usd_bn` | Illustrative revenue value in USD billions | Decimal number; not actual company revenue |
| `service_portfolio` | Semicolon-separated service lines | Text; split on `;` for service-level analysis |
| `geographic_presence` | Semicolon-separated regions represented in the example | Text; not a verified operating footprint |
| `strategic_focus` | Illustrative strategy themes | Semicolon-separated text |
| `genai_focus` | Illustrative flag for GenAI focus | `Yes` / `No`; not a verified company claim |
| `source_notes` | Data provenance note | All current rows say synthetic example |

## Before using real data

Add `source_url`, `source_title`, `publication_date`, `access_date`, `metric_definition`, `currency`, and `source_notes`. Distinguish total company revenue from technology-services revenue and record fiscal-year differences. Cite every external claim.
