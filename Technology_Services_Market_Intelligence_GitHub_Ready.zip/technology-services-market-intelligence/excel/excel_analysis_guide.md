# Excel Analysis Guide

> Practice guide only: the included dataset is synthetic.

## 1. Import the CSV
1. Open Excel.
2. Choose **Data → From Text/CSV** and select `data/provider_benchmark.csv`.
3. Load the data and save a working copy as `provider_benchmark.xlsx`.
4. Select the data and press **Ctrl+T** to format it as a table. Name the table `ProviderBenchmark` under Table Design.

## 2. Add year-over-year growth
Add a new column named `Revenue Growth %`. If rows are sorted by provider and year and the columns match the CSV, use this formula in the second data row and fill down:

`=IF(A3=A2,(C3-C2)/C2,"")`

Format the column as Percentage. This formula assumes column A is provider and column C is revenue; adjust if the sheet differs. The first year for each provider should be blank.

## 3. Create PivotTables
- Revenue trend: Rows = `fiscal_year`; Columns = `provider`; Values = Sum of `revenue_usd_bn`.
- Latest-year comparison: Filter `fiscal_year` to 2024; Rows = `provider`; Values = Sum of `revenue_usd_bn`.
- GenAI focus: Rows = `fiscal_year`; Columns = `genai_focus`; Values = Distinct Count of `provider` if the Excel data model is enabled (otherwise count rows and explain the limitation).

## 4. Sanity checks
- Each provider should have one row per year.
- Confirm revenue is numeric and years are whole numbers.
- Do not mix different revenue definitions or currencies in a real dataset.
- Label all charts as illustrative until the data is replaced with sourced information.
