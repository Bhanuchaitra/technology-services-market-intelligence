from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "provider_benchmark.csv"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

def main():
    df = pd.read_csv(DATA)
    df["provider"] = df["provider"].astype("string").str.strip()
    df["fiscal_year"] = pd.to_numeric(df["fiscal_year"], errors="coerce").astype("Int64")
    df["revenue_usd_bn"] = pd.to_numeric(df["revenue_usd_bn"], errors="coerce")
    df["genai_focus"] = df["genai_focus"].astype("string").str.strip().str.title()
    df = df.dropna(subset=["provider", "fiscal_year", "revenue_usd_bn"])
    df = df.drop_duplicates(subset=["provider", "fiscal_year"], keep="last")
    df = df.sort_values(["provider", "fiscal_year"])

    df["revenue_growth_pct"] = df.groupby("provider")["revenue_usd_bn"].pct_change() * 100
    df.to_csv(OUT / "clean_provider_benchmark.csv", index=False)

    latest_year = df["fiscal_year"].max()
    latest = df[df["fiscal_year"] == latest_year].copy()
    first = df.groupby("provider", as_index=False).first()[["provider", "fiscal_year", "revenue_usd_bn"]]
    last = df.groupby("provider", as_index=False).last()[["provider", "fiscal_year", "revenue_usd_bn"]]
    growth = first.merge(last, on="provider", suffixes=("_first", "_last"))
    growth["period_growth_pct"] = (
        (growth["revenue_usd_bn_last"] / growth["revenue_usd_bn_first"]) ** 
        (1 / (growth["fiscal_year_last"] - growth["fiscal_year_first"])) - 1
    ) * 100
    growth.to_csv(OUT / "revenue_growth_summary.csv", index=False)

    service_rows = []
    for _, row in latest.iterrows():
        for service in str(row["service_portfolio"]).split(";"):
            service_rows.append({"provider": row["provider"], "fiscal_year": int(row["fiscal_year"]), "service_line": service.strip()})
    pd.DataFrame(service_rows).to_csv(OUT / "service_portfolio_summary.csv", index=False)

    print(f"Loaded {len(df)} provider-year records.")
    print(f"Latest year in sample: {latest_year}")
    print("\nLatest-year revenue (illustrative data only):")
    print(latest[["provider", "revenue_usd_bn", "genai_focus"]].sort_values("revenue_usd_bn", ascending=False).to_string(index=False))
    print(f"\nWrote outputs to: {OUT}")

if __name__ == "__main__":
    main()
