# Technology Services Market Intelligence & Competitive Analysis

**Tools:** Excel, SQL (PostgreSQL), Python (pandas), Power BI  
**Portfolio skills demonstrated:** data preparation, exploratory analysis, competitive benchmarking, KPI design, visualisation planning, and executive communication.

> [!IMPORTANT]
> **Data transparency:** this repository currently uses a small synthetic dataset with fictional provider labels and illustrative values. It is a working portfolio prototype, not verified market research. Do not present its numbers as real company results. Replace the data with publicly sourced, comparable figures before drawing real-world conclusions.

## Business objective
Create a repeatable workflow to compare technology-services providers across revenue trends, service portfolios, geographic presence, strategic themes, and GenAI focus.

## Questions explored
1. How did illustrative revenue change over time for each provider?
2. Which service lines appear in each provider's example portfolio?
3. How does the example geographic presence differ?
4. How many providers are marked as having a GenAI focus in the sample?
5. What data-quality and comparability issues should an analyst check before presenting conclusions?

## Repository map

```text
technology-services-market-intelligence/
├── data/
│   ├── provider_benchmark.csv
│   ├── data_dictionary.md
│   └── source_register_template.csv
├── excel/
│   └── excel_analysis_guide.md
├── sql/
│   └── analysis_queries.sql
├── src/
│   └── analyze_market.py
├── outputs/
│   ├── clean_provider_benchmark.csv
│   ├── revenue_growth_summary.csv
│   └── service_portfolio_summary.csv
├── powerbi/
│   └── dashboard_build_guide.md
├── reports/
│   └── executive_summary_template.md
├── .gitignore
├── requirements.txt
└── README.md
```

## Run the Python analysis

Requires Python 3.10 or newer.

```bash
python -m pip install -r requirements.txt
python src/analyze_market.py
```

The script cleans basic fields, removes duplicate provider-year records, calculates year-over-year growth, and writes three CSV outputs to `outputs/`.

## Tools and workflow

- **Excel:** import and inspect the CSV, calculate growth, build PivotTables. See `excel/excel_analysis_guide.md`.
- **SQL:** practice window functions and grouping using PostgreSQL. See `sql/analysis_queries.sql`.
- **Python:** repeat data cleaning and summary calculations. See `src/analyze_market.py`.
- **Power BI:** build KPI cards, provider comparisons, a revenue trend chart, and slicers. See `powerbi/dashboard_build_guide.md`.
- **Executive reporting:** use `reports/executive_summary_template.md` only after checking the data and documenting sources.

## Methodology for a real-data version

1. Choose a consistent set of providers and a defined reporting period.
2. Collect data from annual reports, investor relations pages, filings, and reputable industry publications.
3. Record source URLs, source titles, publication dates, access dates, metric definitions, units, and caveats in `data/source_register_template.csv`.
4. Distinguish total company revenue from technology-services revenue. They are not automatically comparable.
5. Convert currencies or units only with a documented method and date/rate where relevant.
6. Separate facts from analyst interpretation and cite factual claims in the report.
7. Replace fictional names and values; then rerun the analysis and update the dashboard.

## Limitations
- The current data is synthetic and deliberately small.
- The `service_portfolio` and `geographic_presence` fields are semicolon-separated labels, not a normalised company-service database.
- GenAI focus is a fictional practice flag, not a verified claim.
- Revenue comparisons are only meaningful when metric definitions, fiscal periods, currency, and business scope are comparable.

## Suggested GitHub description

`Portfolio prototype using Excel, PostgreSQL, Python and Power BI for technology-services benchmarking and market analysis.`

## Resume wording

Until you replace the synthetic data and finish the dashboard, describe this as a **prototype using illustrative data**. After completing the project, update the bullets to accurately reflect the data sources, period, analyses, dashboard and verified outcomes. Do not claim business impact that you did not measure.
